public class TaskBall : Task
{
    protected override void TaskComplete(TaskType taskType)
    {
        if (_taskType == taskType)
        {
            _taskValueCount = _taskValueCountTarget;
            UpdateText("+");
        }
    }
}
