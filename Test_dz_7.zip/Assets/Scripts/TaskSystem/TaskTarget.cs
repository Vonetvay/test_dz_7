using UnityEngine;
using UnityEngine.Events;

public class TaskTarget : MonoBehaviour
{
    [SerializeField] private TaskType _taskType;
    public static UnityEvent<TaskType> s_taskComplete = new UnityEvent<TaskType>();

    public void TaskComplete() 
    {
        s_taskComplete?.Invoke(_taskType);
    }
}
