using TMPro;
using UnityEngine;

public enum TaskType
{
    Box,
    Barrel,
    Stone,
    Ball
}

public class Task : MonoBehaviour
{
    [SerializeField] protected TaskType _taskType;

    [SerializeField] private Color _notCompleteColor;
    [SerializeField] private Color _completeColor;

    [SerializeField] private TextMeshProUGUI _text;
    [SerializeField] protected int _taskValueCountTarget;
    protected int _taskValueCount;

    private bool _isComplete;

    private void OnEnable()
    {
        TaskTarget.s_taskComplete.AddListener(TaskComplete);
    }

    private void OnDisable()
    {
        TaskTarget.s_taskComplete.RemoveListener(TaskComplete);
    }

    protected virtual void TaskComplete(TaskType taskType) 
    {
        UpdateText($"{_taskValueCount}/{_taskValueCountTarget}");
    }

    protected void UpdateText(string text)
    {
        _text.text = text;
        _text.color = _taskValueCount >= _taskValueCountTarget ? _completeColor : _notCompleteColor;
        if (_taskValueCount == _taskValueCountTarget && !_isComplete) 
        {
            _isComplete = true;
            FindFirstObjectByType<ShowNextLevel>().AddTask();
        }
    }
}
