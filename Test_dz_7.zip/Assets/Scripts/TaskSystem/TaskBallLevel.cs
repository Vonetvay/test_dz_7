using UnityEngine;

public class TaskBallLevel : MonoBehaviour
{
    [SerializeField] private int _ballTaskLevel;

    public int GetBallTaskLevel() => _ballTaskLevel;
}
