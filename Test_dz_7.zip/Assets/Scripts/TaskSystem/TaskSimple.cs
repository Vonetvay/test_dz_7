public class TaskSimple : Task
{
    private void Awake()
    {
        UpdateText($"{_taskValueCount}/{_taskValueCountTarget}");
    }

    protected override void TaskComplete(TaskType taskType)
    {
        if (_taskType == taskType)
        {
            _taskValueCount++;
            base.TaskComplete(taskType);
        }
    }
}
