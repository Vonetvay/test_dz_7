using UnityEngine;

public class ShowNextLevel : MonoBehaviour
{
    [SerializeField] private GameObject _panel;
    [SerializeField] private Animator _panelAnimator;

    [SerializeField] private int _taskValue;
    private int _currentTaskValue = 0;

    public void AddTask() 
    {
        _currentTaskValue++;
        if (_currentTaskValue == _taskValue) 
        {
            _panel.SetActive(true);
            _panelAnimator.SetTrigger("Show");
        }
    }
}
