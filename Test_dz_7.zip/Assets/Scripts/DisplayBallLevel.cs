using UnityEngine;
using TMPro;

public class DisplayBallLevel : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI _text;

    private MeshRenderer _meshRenderer;
    private BallSettings _ballSettings;
    private BallLevel _ballLevel;

    private void Awake()
    {
        _meshRenderer = GetComponent<MeshRenderer>();
        _ballLevel = GetComponent<BallLevel>();
        _ballSettings = FindObjectOfType<BallSettings>();
        Display();
    }

    public void Display()
    {
        _text.text = (Mathf.Pow(2, _ballLevel.level + 1)).ToString();
        _meshRenderer.material = _ballSettings.GetMaterial(_ballLevel.level);
    }
}
