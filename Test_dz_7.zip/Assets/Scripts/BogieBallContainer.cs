using UnityEngine;

public class BogieBallContainer : MonoBehaviour
{
    [HideInInspector] public GameObject ball;

    private BallCreator _ballCreator;

    private void Awake()
    {
        _ballCreator = FindObjectOfType<BallCreator>();
    }

    private void Update()
    {
        if (Input.GetMouseButtonUp(0) && ball != null)
        {
            Drop();
        }
    }

    public void Drop()
    {
        _ballCreator.SetCanLaunch(true);
        ball.GetComponent<Rigidbody>().isKinematic = false;
        ball.GetComponent<FlyBall>().enabled = false;
        ball = null;
    }
}
