using UnityEngine;

public class BallLevel : MonoBehaviour
{
    [SerializeField] public int level;

    private BallSettings _ballSettings;

    private void Awake()
    {
        _ballSettings = FindObjectOfType<BallSettings>();
    }

    public void AddLevel() 
    {
        if (level < _ballSettings.GetMaxLevel()) 
        {
            level++;
        }
    }
}
