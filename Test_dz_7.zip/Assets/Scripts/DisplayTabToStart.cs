using UnityEngine;

public class DisplayTabToStart : MonoBehaviour
{
    [SerializeField] private GameObject _message;
    
    public void DestroyMessage() 
    {
        Destroy(_message);
    }
}
