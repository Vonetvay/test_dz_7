using UnityEngine;

public class BogieMovement : MonoBehaviour
{
    [SerializeField] private float _moveSpeed;
    [SerializeField] private Vector2 _moveInterval;
    [SerializeField] private float _gameArea;

    private BogieBallContainer _bogieBallContainer;

    private void Awake()
    {
        _bogieBallContainer = GetComponent<BogieBallContainer>();
    }

    private void LateUpdate()
    {
        float _mousePose = Input.mousePosition.x / (Screen.width / _gameArea) - (_gameArea / 2);
        if (_mousePose < _moveInterval.y && _mousePose > _moveInterval.x)
        {
            transform.position = new Vector3(_mousePose, transform.position.y, transform.position.z);
        }
        if (_bogieBallContainer.ball != null) 
        {
            _bogieBallContainer.ball.transform.position = transform.position;
        }
    }
}