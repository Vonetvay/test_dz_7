using UnityEngine;

public class BallSettings : MonoBehaviour
{
    public int _maxLevel = 10;
    [SerializeField] private Material[] _materials;

    public int GetMaxLevel() 
    {
        return _maxLevel;
    }

    public Material GetMaterial(int id) 
    {
        return _materials[id];
    }
}
